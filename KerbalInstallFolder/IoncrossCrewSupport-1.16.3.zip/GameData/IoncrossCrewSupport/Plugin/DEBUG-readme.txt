There is a second dll renamed to IoncrossCrewSupport.dll.DEBUG

If you want to see debug messages in the game log:

rename the existing IoncrossCrewSupport.dll to IoncrossCrewSupport.dll.BACKUP
rename IoncrossCrewSupport.dll.DEBUG to IoncrossCrewSupport.dll

to reverse (and get back to non-debug version)
rename IoncrossCrewSupport.dll to IoncrossCrewSupport.dll.DEBUG
rename IoncrossCrewSupport.dll.BACKUP to IoncrossCrewSupport.dll