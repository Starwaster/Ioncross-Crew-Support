This work is branched off under Yongedevil's original license found below. Additionally, Yongedevil has granted permission for me to host the original mod.

Licence
Modified source code, compiled dll, and configuration files may be distributed provided they attribute the original work to me, yongedevil. However, I request you do not simply re-post the original mod as I prefer it control where it is hosted myself.

Additional License Info:
Anything added by Starwaster post ver 1.1 (toolbar integration, contracts, etc) is licensed under Creative Commons Attribution-ShareAlike 4.0 International License.